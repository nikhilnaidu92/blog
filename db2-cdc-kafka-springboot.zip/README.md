# DB2 CDC to Kafka to Database

This project demonstrates how to stream Change Data Capture (CDC) logs from IBM Db2 to another database using Kafka, Debezium, and Spring Boot.

## Setup Instructions
1. **Clone the repository:**
   ```bash
   git clone https://github.com/YOUR_USERNAME/db2-cdc-kafka-springboot.git
   cd db2-cdc-kafka-springboot
   ```
2. **Start Kafka and Zookeeper:**
   ```bash
   docker-compose up -d
   ```
3. **Register the Debezium Connector:**
   ```bash
   curl -X POST -H "Content-Type: application/json" --data @debezium/debezium-connector.json http://localhost:8083/connectors
   ```
4. **Run the Spring Boot application:**
   ```bash
   ./mvnw spring-boot:run
   ```

Check the `README.md` for more details.