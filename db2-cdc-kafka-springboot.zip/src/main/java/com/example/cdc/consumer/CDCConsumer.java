package com.example.cdc.consumer;

import com.example.cdc.model.CDCEvent;
import com.example.cdc.service.TargetDBService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class CDCConsumer {

    @Autowired
    private TargetDBService service;

    @KafkaListener(topics = "db2cdc.schema.table", groupId = "cdc-group")
    public void consume(String message) {
        log.info("Received CDC event: {}", message);
        try {
            CDCEvent event = new ObjectMapper().readValue(message, CDCEvent.class);
            service.saveCDCEvent(event);
        } catch (Exception e) {
            log.error("Error processing CDC event", e);
        }
    }
}