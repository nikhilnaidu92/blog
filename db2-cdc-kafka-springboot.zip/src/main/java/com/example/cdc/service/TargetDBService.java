package com.example.cdc.service;

import com.example.cdc.model.CDCEvent;
import org.springframework.stereotype.Service;

@Service
public class TargetDBService {

    public void saveCDCEvent(CDCEvent event) {
        System.out.println("Saving event to target DB: " + event);
        // Implement JDBC or JPA logic to persist to target DB
    }
}