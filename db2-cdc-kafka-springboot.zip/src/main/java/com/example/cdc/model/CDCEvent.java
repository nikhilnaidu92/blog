package com.example.cdc.model;

import lombok.Data;
import java.util.Map;

@Data
public class CDCEvent {
    private String operation; // "CREATE", "UPDATE", "DELETE"
    private Map<String, Object> before;
    private Map<String, Object> after;
}